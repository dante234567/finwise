// ─── Store global con Zustand + persistencia en localStorage ────────────────
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { MOCK_MOVIMIENTOS, MOCK_PRESUPUESTOS, MOCK_CATEGORIAS_GASTO, MOCK_PERFIL } from '../data/mockData'

// Genera un ID único simple
const uid = () => Math.random().toString(36).slice(2, 9)

const useStore = create(
  persist(
    (set, get) => ({
      // ── Perfil ──────────────────────────────────────────────────────────────
      perfil: MOCK_PERFIL,
      updatePerfil: (data) => set((s) => ({ perfil: { ...s.perfil, ...data } })),

      // ── Movimientos (ingresos y egresos) ────────────────────────────────────
      movimientos: MOCK_MOVIMIENTOS,

      addMovimiento: (mov) =>
        set((s) => ({
          movimientos: [{ ...mov, id: uid(), fecha: new Date().toISOString() }, ...s.movimientos],
        })),

      updateMovimiento: (id, data) =>
        set((s) => ({
          movimientos: s.movimientos.map((m) => (m.id === id ? { ...m, ...data } : m)),
        })),

      deleteMovimiento: (id) =>
        set((s) => ({ movimientos: s.movimientos.filter((m) => m.id !== id) })),

      // ── Presupuestos ────────────────────────────────────────────────────────
      presupuestos: MOCK_PRESUPUESTOS,

      addPresupuesto: (p) =>
        set((s) => ({
          presupuestos: [{ ...p, id: uid(), fecha: new Date().toISOString() }, ...s.presupuestos],
        })),

      updatePresupuesto: (id, data) =>
        set((s) => ({
          presupuestos: s.presupuestos.map((p) => (p.id === id ? { ...p, ...data } : p)),
        })),

      deletePresupuesto: (id) =>
        set((s) => ({ presupuestos: s.presupuestos.filter((p) => p.id !== id) })),

      // ── Categorías de gasto ─────────────────────────────────────────────────
      categorias: MOCK_CATEGORIAS_GASTO,

      updateCategoria: (nombre, data) =>
        set((s) => ({
          categorias: s.categorias.map((c) => (c.nombre === nombre ? { ...c, ...data } : c)),
        })),

      // ── Computed helpers (se usan en múltiples páginas) ─────────────────────
      getTotalesMes: () => {
        const movs = get().movimientos
        const ahora = new Date()
        const deEsteMes = movs.filter((m) => {
          const d = new Date(m.fecha)
          return d.getMonth() === ahora.getMonth() && d.getFullYear() === ahora.getFullYear()
        })
        const ingresos = deEsteMes.filter((m) => m.tipo === 'ingreso').reduce((a, m) => a + m.monto, 0)
        const egresos  = deEsteMes.filter((m) => m.tipo === 'egreso').reduce((a, m) => a + m.monto, 0)
        const ganancia = ingresos - egresos
        const bolsillo = Math.round(ganancia * (get().perfil.porcentajeBolsillo / 100))
        return { ingresos, egresos, ganancia, bolsillo }
      },

      getGastosPorCategoria: () => {
        const movs = get().movimientos.filter((m) => m.tipo === 'egreso')
        const ahora = new Date()
        const deEsteMes = movs.filter((m) => {
          const d = new Date(m.fecha)
          return d.getMonth() === ahora.getMonth() && d.getFullYear() === ahora.getFullYear()
        })
        return get().categorias.map((cat) => ({
          ...cat,
          gastado: deEsteMes.filter((m) => m.categoria === cat.nombre).reduce((a, m) => a + m.monto, 0),
        }))
      },
    }),
    {
      name: 'flowapp-storage', // clave en localStorage
    }
  )
)

export default useStore
